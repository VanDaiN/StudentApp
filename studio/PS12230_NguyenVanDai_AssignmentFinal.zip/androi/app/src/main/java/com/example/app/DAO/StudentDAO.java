package com.example.app.DAO;

import android.content.Context;
import android.util.Log;


import com.example.app.Model.Students;
import com.example.app.noUI;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.List;

import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;


public class StudentDAO {

    Context context;
    String serverUrl = "http://192.168.1.6:3001";
    List<Students> list = new ArrayList<Students>();


    //Khai bao socketx`
    private Socket mSocket;
    {
        try {
            mSocket = IO.socket(serverUrl);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    //lang nghe insert
    private Emitter.Listener onInsertStudent = new Emitter.Listener() {
        @Override
        public void call(Object... args) {
            String data =  args[0].toString();

            noUI noui = new noUI(context);

            if(data == "true"){
                Log.i("insert","Insert thanh cong");

                noui.toast("Insert thanh cong");
                noui.capnhatListView();





            }else{

                Log.i("insert","Insert that bai");

                noui.toast("Insert that bai");

            }

        }
    };
    //lang nghe getAll
    private Emitter.Listener onGetAllStudent = new Emitter.Listener() {
        @Override
        public void call(Object... args) {

                Students sv = new Students();

                JSONObject jsonObject = (JSONObject) args[0];
                //parser JSON
                try {
                    sv._id = jsonObject.getString("_id");
                    sv.id = jsonObject.getString("id");
                    sv.name = jsonObject.getString("name");
                    sv.email = jsonObject.getString("email");

                    list.add(sv);


                } catch (JSONException e) {
                    e.printStackTrace();
                }

                noUI noui = new noUI(context);
                if(!list.isEmpty()){


                        Log.i("GetAll","GetAll thanh cong");

                        noui.toast("GetAll thanh cong");


                }else{

                    Log.i("GetAll","GetAll that bai");

                    noui.toast("GetAll that bai");
                }


        }
    };



    public StudentDAO(Context context) {
        this.context = context;
        mSocket.connect();
        mSocket.on("insertStudent", onInsertStudent);
        mSocket.on("getStudent", onGetAllStudent);
    }



    public void insert(final Students sv) {

        mSocket.emit("insertStudent", sv.id, sv.name, sv.email);


    }

    public List<Students> getAll(){

        list.clear();

        mSocket.emit("getStudent","Client Android get All Student");



        return list;
    }

    public void update(final Students sv) {



    }

    public void delete(final String id) {



    }
}
