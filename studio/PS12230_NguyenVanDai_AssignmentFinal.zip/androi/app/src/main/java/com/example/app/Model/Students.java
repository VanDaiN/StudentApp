package com.example.app.Model;

public class Students {
    public String _id;
    public String id;
    public String name;
    public String email;

    public Students() {
    }

    public Students(String id, String name, String email) {
        this.id = id;
        this.name = name;
        this.email = email;
    }
}
